document.getElementById('searchForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const query = document.getElementById('searchInput').value.trim().toLowerCase();

    if (query === '') {
        alert('لطفاً یک کلمه کلیدی وارد کنید');
        return;
    }

   
    const menuItems = document.querySelectorAll('.nav-link');

    let targetUrl = null;

    for (const item of menuItems) {
        const text = item.textContent.trim().toLowerCase();
        const href = item.getAttribute('href');

      
        if (text.includes(query)) {
            targetUrl = href;
            break;
        }
    }

    if (targetUrl && targetUrl !== '#') {
        window.location.href = targetUrl;
    } else {
        alert('صفحه‌ای با این نام یافت نشد');
    }
});