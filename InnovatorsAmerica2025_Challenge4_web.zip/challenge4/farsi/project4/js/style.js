function uint8ArrayToBase64(bytes) {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function base64ToUint8Array(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}

const charToEmoji = {
    'A': '🍎', 'B': '🍌', 'C': '🍒', 'D': '🍇', 'E': '🍊',
    'F': '🍋', 'G': '🍉', 'H': '🍓', 'I': '🍑', 'J': '🍍',
    'K': '🥥', 'L': '🥝', 'M': '🍅', 'N': '🍆', 'O': '🥑',
    'P': '🥦', 'Q': '🥕', 'R': '🌽', 'S': '🌶', 'T': '🥒',
    'U': '🥬', 'V': '🥭', 'W': '🍐', 'X': '🧶', 'Y': '🌙', 'Z': '🥔',
    'a': '🍏', 'b': '🪴', 'c': '🌼', 'd': '🌻', 'e': '🪻',
    'f': '🌴', 'g': '🌱', 'h': '🌿', 'i': '☘️', 'j': '🍀',
    'k': '🍁', 'l': '🍂', 'm': '🍃', 'n': '🪨', 'o': '🐚',
    'p': '🪵', 'q': '🌾', 'r': '🌵', 's': '🌷', 't': '🌹',
    'u': '🥀', 'v': '🌺', 'w': '🌎', 'x': '🌍', 'y': '🌏', 'z': '🌐',
    '0': '⚽', '1': '🥇', '2': '🥈', '3': '🥉', '4': '🎲',
    '5': '🎯', '6': '🏀', '7': '🏈', '8': '🚗', '9': '🚀',
    '+': '➕',
    '/': '➖',
    '=': '🟰'
};


const emojiToChar = {};
for (const [char, emoji] of Object.entries(charToEmoji)) {
    emojiToChar[emoji] = char;
}


async function generateKeyFromPassword(password) {
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );
    return await crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: encoder.encode("static-salt-for-demo-only"),
            iterations: 100000,
            hash: "SHA-256"
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
    );
}


async function ramznegar() {
    const messageInput = document.getElementById('message');
    const passwordInput = document.getElementById('password');
    const text = messageInput.value;
    const password = passwordInput.value.trim();
    const container = document.getElementById('encryptedImage');
    const emojiOutput = document.getElementById('emojiOutput');

    if (!text) {
        alert('لطفاً یک متن وارد کنید!');
        return;
    }
    if (!password) {
        alert('لطفاً یک رمز عبور وارد کنید!');
        return;
    }

    try {
        const key = await generateKeyFromPassword(password);
        const encoder = new TextEncoder();
        const data = encoder.encode(text);
        const iv = crypto.getRandomValues(new Uint8Array(12));

        const encrypted = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv: iv },
            key,
            data
        );

        const encryptedArray = new Uint8Array(encrypted);
        const combined = new Uint8Array(iv.length + encryptedArray.length);
        combined.set(iv);
        combined.set(encryptedArray, iv.length);

        const base64Str = uint8ArrayToBase64(combined);

  
        console.log("[رمزنگاری] Base64 تولیدشده:", base64Str);

        container.innerHTML = '';
        let emojiString = '';

        for (const char of base64Str) {
            const emoji = charToEmoji[char] || '❓';
            emojiString += emoji;

            const span = document.createElement('span');
            span.className = 'emoji';
            span.textContent = emoji;
            container.appendChild(span);
        }

        emojiOutput.value = emojiString;

    } catch (e) {
        console.error("خطا در رمزنگاری:", e);
        alert('خطا در رمزنگاری:\n' + e.message);
    }
}


async function copyEmojis() {
    const output = document.getElementById('emojiOutput');
    try {
        await navigator.clipboard.writeText(output.value);
        alert('ایموجی‌ها کپی شدند! 🎉');
    } catch (err) {
        console.error('کپی ناموفق:', err);
        alert('کپی ناموفق بود. لطفاً دستی کپی کنید.');
    }
}


async function ramzgoshaFromEmojis() {
    const rawInput = document.getElementById('pasteEmojis').value;
    const password = document.getElementById('decryptPassword').value.trim();
    const result = document.getElementById('decryptedText');

    if (!rawInput || rawInput.trim().length === 0) {
        result.textContent = 'لطفاً ایموجی‌ها را بچسبانید!';
        return;
    }
    if (!password) {
        result.textContent = 'لطفاً رمز عبور را وارد کنید!';
        return;
    }

    try {
        let base64Str = '';
        for (const emoji of rawInput) {
            if (emoji in emojiToChar) {
                base64Str += emojiToChar[emoji];
            }
        }

      
        console.log("[رمزگشایی] Base64 بازسازی‌شده:", base64Str);

        if (base64Str.length === 0) {
            throw new Error('هیچ کاراکتر معتبر Base64ای پیدا نشد.');
        }

     
        if (!/^[A-Za-z0-9+/=]+$/.test(base64Str)) {
            throw new Error('رشته Base64 حاوی کاراکتر غیرمجاز است.');
        }

        const combined = base64ToUint8Array(base64Str);

        if (combined.length <= 12) {
            throw new Error('داده ناقص است — IV (12 بایت) + حداقل یک بایت داده لازم است.');
        }

        const iv = combined.slice(0, 12);
        const data = combined.slice(12);

        const key = await generateKeyFromPassword(password);
        const decrypted = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: iv },
            key,
            data
        );

        const decoder = new TextDecoder("utf-8");
        const originalText = decoder.decode(decrypted);
        result.textContent = 'متن رمزگشایی‌شده: ' + originalText;

    } catch (e) {
        console.error("خطا در رمزگشایی:", e);
        result.textContent = '❌ خطا: ' + (e.message || 'رمزگشایی ناموفق — داده ناسازگار');
    }
}

function resetAllr() {
    document.getElementById('message').value = '';
    document.getElementById('password').value = '';
    document.getElementById('emojiOutput').value = '';
    document.getElementById('encryptedImage').innerHTML = '<p style="color: #888; margin: 0;">ایموجی‌ها اینجا نمایش داده می‌شوند</p>';
}

function resetAllg() {
    document.getElementById('pasteEmojis').value = '';
    document.getElementById('decryptPassword').value = '';
    document.getElementById('decryptedText').textContent = 'متن رمزگشایی‌شده اینجا نمایش داده می‌شود';
}

