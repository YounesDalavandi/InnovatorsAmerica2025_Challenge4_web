function hasEnglishLetters(text) {
  const englishRegex = /[a-zA-Z]/;
  return englishRegex.test(text);
}

async function generateKey(password) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  return await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: encoder.encode("salt-salt-salt-unique"),
      iterations: 100000,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function encrypt() {
  const input = document.getElementById("inputText").value;
  const password = document.getElementById("password").value;
  const output = document.getElementById("outputText");

  if (!input) return alert("Please enter some text to encrypt.");
  if (!password) return alert("Please enter a password.");

  if (hasEnglishLetters(input)) {
    alert("❌ English letters (A-Z, a-z) are not allowed.\nPlease remove them.");
    output.value = "Blocked: English letters detected.";
    return;
  }

  try {
    const key = await generateKey(password);
    const encoder = new TextEncoder();
    const data = encoder.encode(input);

    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: iv },
      key,
      data
    );

    const encryptedArray = new Uint8Array(encrypted);
    const combined = new Uint8Array(iv.length + encryptedArray.length);
    combined.set(iv);
    combined.set(encryptedArray, iv.length);

    const base64Data = btoa(String.fromCharCode(...combined));
    output.value = base64Data;
  } catch (e) {
    output.value = "Encryption error: " + e.message;
  }
}

function copyOutput() {
  const output = document.getElementById("outputText");
  if (!output.value) return alert("No output to copy.");
  output.select();
  document.execCommand("copy");
  alert("✅ Output copied to clipboard!");
}


function reset() {
  document.getElementById("inputText").value = "";
  document.getElementById("password").value = "";
  document.getElementById("outputText").value = "";
  document.getElementById("inputText").focus();
}




function hasEnglishLetters(text) {
  const englishRegex = /[a-zA-Z]/;
  return englishRegex.test(text);
}

function cleanBase64(str) {
  return str.trim().replace(/[\u200B-\u200D\uFEFF\r\n\t\s]+/g, "");
}

async function generateKey(password) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  return await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: encoder.encode("salt-salt-salt-unique"),
      iterations: 100000,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function decrypt() {
  let input = document.getElementById("inputText").value;
  const password = document.getElementById("password").value;
  const output = document.getElementById("outputText");

  if (!input) return alert("Please enter encrypted text to decrypt.");
  if (!password) return alert("Please enter the password.");

  input = cleanBase64(input);

  if (!/^[A-Za-z0-9+/=]+$/.test(input)) {
    output.value = "❌ Invalid base64 format.";
    return;
  }

  try {
    const key = await generateKey(password);
    const decoded = atob(input);
    const combined = Uint8Array.from(decoded, c => c.charCodeAt(0));

    if (combined.length < 12) throw new Error("Invalid data.");

    const iv = combined.slice(0, 12);
    const data = combined.slice(12);

    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv },
      key,
      data
    );

    const plainText = new TextDecoder("utf-8").decode(decrypted);

 
    if (hasEnglishLetters(plainText)) {
      output.value = "❌ Decryption blocked — output contains English letters.";
    } else {
      output.value = plainText;
    }
  } catch (e) {
    output.value = "Decryption failed — wrong password or invalid data.";
  }
}


function copyOutput() {
  const output = document.getElementById("outputText");
  if (!output.value) return alert("No output to copy.");
  output.select();
  document.execCommand("copy");
  alert("✅ Output copied to clipboard!");
}


function reset() {
  document.getElementById("inputText").value = "";
  document.getElementById("password").value = "";
  document.getElementById("outputText").value = "";
  document.getElementById("inputText").focus();
}
