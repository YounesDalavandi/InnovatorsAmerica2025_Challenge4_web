async function generateKey(password) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  return await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: encoder.encode("salt-salt-salt-unique"),
      iterations: 100000,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function encrypt() {
  const input = document.getElementById("inputText").value;
  const password = document.getElementById("password").value;
  const output = document.getElementById("outputText");

  if (!input) {
    alert("الرجاء إدخال نص للتشفيـر.");
    return;
  }
  if (!password) {
    alert("الرجاء إدخال كلمة المرور.");
    return;
  }
  try {
    const key = await generateKey(password);
    const encoder = new TextEncoder();
    const data = encoder.encode(input);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: iv },
      key,
      data
    );

    const encryptedArray = new Uint8Array(encrypted);
    const combined = new Uint8Array(iv.length + encryptedArray.length);
    combined.set(iv);
    combined.set(encryptedArray, iv.length);
    const base64 = btoa(
      Array.from(combined, byte => String.fromCharCode(byte)).join('')
    );

    output.value = base64;

  } catch (e) {
    console.error(e);
    output.value = "خطأ في التشفير: " + e.message;
  }
}

function copyOutput() {
  const output = document.getElementById("outputText");
  if (!output.value) {
    alert("لا يوجد شيء للنسخ.");
    return;
  }
  output.select();
  document.execCommand("copy");
  alert("✅ تم النسخ إلى الحافظة!");
}

function reset() {
  document.getElementById("inputText").value = "";
  document.getElementById("password").value = "";
  document.getElementById("outputText").value = "";
  document.getElementById("inputText").focus();
}

function cleanBase64(str) {
  return str.trim().replace(/[\u200B-\u200D\uFEFF\r\n\t\s]+/g, "");
}

async function decrypt() {
  let input = document.getElementById("inputText").value;
  const password = document.getElementById("password").value;
  const output = document.getElementById("outputText");

  if (!input) {
    alert("الرجاء لصق النص المشفر.");
    return;
  }
  if (!password) {
    alert("الرجاء إدخال كلمة المرور.");
    return;
  }

  input = cleanBase64(input);

  if (!/^[A-Za-z0-9+/=]+$/.test(input)) {
    output.value = "❌ تنسيق base64 غير صالح.";
    return;
  }
  try {
    const key = await generateKey(password);
    const decoded = atob(input);
    const combined = new Uint8Array(decoded.length);
    for (let i = 0; i < decoded.length; i++) {
      combined[i] = decoded.charCodeAt(i);
    }
    if (combined.length < 12) {
      throw new Error("بيانات غير صالحة.");
    }

    const iv = combined.slice(0, 12);
    const data = combined.slice(12);
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv },
      key,
      data
    );

    const plainText = new TextDecoder("utf-8").decode(decrypted);
    output.value = plainText;

  } catch (e) {
    console.error(e);
    output.value = "❌ فشل فك التشفير — كلمة مرور خاطئة أو بيانات تالفة";
  }
}