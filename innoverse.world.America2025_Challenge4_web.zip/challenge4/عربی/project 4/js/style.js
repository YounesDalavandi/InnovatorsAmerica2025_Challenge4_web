
const charToEmoji = {
    'A': '🍎', 'B': '🍌', 'C': '🍒', 'D': '🍇', 'E': '🍊',
    'F': '🍋', 'G': '🍉', 'H': '🍓', 'I': '🍑', 'J': '🍍',
    'K': '🥥', 'L': '🥝', 'M': '🍅', 'N': '🍆', 'O': '🥑',
    'P': '🥦', 'Q': '🥕', 'R': '🌽', 'S': '🌶', 'T': '🥒',
    'U': '🥬', 'V': '🥭', 'W': '🍐', 'X': '🧶', 'Y': '🌙', 'Z': '🥔',

    'a': '🍏', 'b': '🪴', 'c': '🌼', 'd': '🌻', 'e': '🪻',
    'f': '🌴', 'g': '🌱', 'h': '🌿', 'i': '☘️', 'j': '🍀',
    'k': '🍁', 'l': '🍂', 'm': '🍃', 'n': '🪨', 'o': '🐚',
    'p': '🪵', 'q': '🌾', 'r': '🌵', 's': '🌷', 't': '🌹',
    'u': '🥀', 'v': '🌺', 'w': '🌎', 'x': '🌍', 'y': '🌏', 'z': '🌐',

    '0': '⚽', '1': '🥇', '2': '🥈', '3': '🥉', '4': '🎲',
    '5': '🎯', '6': '🏀', '7': '🏈', '8': '🚗', '9': '🚀',

    '+': '➕', '/': '➖', '=': '🟰', ' ': '⬜'
};


const emojiToChar = {};
for (let [char, emoji] of Object.entries(charToEmoji)) {
    emojiToChar[emoji] = char;
}

emojiToChar['☘'] = 'i';
emojiToChar['🌍'] = 'x';
emojiToChar['🌎'] = 'w';
emojiToChar['🌏'] = 'y';
emojiToChar['🌱'] = 'g';
emojiToChar['🍀'] = 'j';
emojiToChar['🌼'] = 'c';
emojiToChar['🌴'] = 'f';
emojiToChar['🍁'] = 'k';

async function generateKey(password) {
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );

    return await crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: encoder.encode("salt-salt-salt-unique"),
            iterations: 100000,
            hash: "SHA-256"
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
    );
}

async function ramznegar() {
    const input = document.getElementById('message');
    const passwordInput = document.getElementById('userPassword');
    const text = input.value;
    const password = passwordInput.value.trim();

    const container = document.getElementById('encryptedImage');
    const emojiOutput = document.getElementById('emojiOutput');

    if (!text) {
        alert('الرجاء إدخال نص!');
        return;
    }
    if (!password) {
        alert('الرجاء إدخال كلمة المرور!');
        return;
    }

    try {
        const key = await generateKey(password);
        const encoder = new TextEncoder();
        const data = encoder.encode(text);

        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv: iv },
            key,
            data
        );

        const encryptedArray = new Uint8Array(encrypted);
        const combined = new Uint8Array(iv.length + encryptedArray.length);
        combined.set(iv);
        combined.set(encryptedArray, iv.length);

        const base64Data = btoa(
            Array.from(combined, byte => String.fromCharCode(byte)).join('')
        );


        container.innerHTML = '';
        let emojiString = '';

        for (let char of base64Data) {
            const emoji = charToEmoji[char] || '❓';
            emojiString += emoji;

            const div = document.createElement('div');
            div.className = 'emoji-block';
            div.textContent = emoji;
            div.style.cssText = `
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 30px;
                height: 30px;
                margin: 2px;
                font-size: 20px;
                border-radius: 8px;
                background: ${getStyleForChar(char).match(/background:([^;]+)/)?.[1] || '#ccc'};
                color: white;
                text-shadow: 0 0 2px black;
            `;
            container.appendChild(div);
        }

        emojiOutput.value = emojiString;

    } catch (e) {
        console.error(e);
        alert('خطأ في التشفير: ' + e.message);
    }
}

function getStyleForChar(char) {
    if (/[A-E]/.test(char)) return 'width:30px;height:30px;background:#ff4444;';
    if (/[F-J]/.test(char)) return 'width:30px;height:30px;background:#4488ff;border-radius:50%;';
    if (/[K-O]/.test(char)) return 'width:0;height:0;border-left:15px solid transparent;border-right:15px solid transparent;border-bottom:30px solid #44ff44;';
    if (/[P-T]/.test(char)) return 'width:22px;height:22px;background:#ffcc00;transform:rotate(45deg);';
    if (/[U-Z]/.test(char)) return 'width:30px;height:30px;background:#aa66cc;border:2px solid #000;';
    if (/[a-e]/.test(char)) return 'width:30px;height:30px;background:#ff9900;opacity:0.8;';
    if (/[f-j]/.test(char)) return 'width:30px;height:30px;background:#00ccaa;';
    if (/[k-o]/.test(char)) return 'width:30px;height:30px;background:#cc5555;border-radius:5px;';
    if (/[p-t]/.test(char)) return 'width:30px;height:30px;background:#55cc55;';
    if (/[u-z]/.test(char)) return 'width:30px;height:30px;background:#5555cc;';
    if (/[0-4]/.test(char)) return 'width:30px;height:30px;background:#ccaa00;';
    if (/[5-9]/.test(char)) return 'width:30px;height:30px;background:#aa00aa;';
    if (char === '+') return 'width:30px;height:30px;background:#ffffff;border:2px solid #000;';
    if (char === '/') return 'width:30px;height:30px;background:#000000;';
    if (char === '=') return 'width:30px;height:30px;background:#666666;';
    return 'width:30px;height:30px;background:#cccccc;';
}


function copyEmojis() {
    const output = document.getElementById('emojiOutput');
    output.select();
    document.execCommand('copy');
    alert('تم نسخ الرموز! 🎉');
}

async function ramzgoshaFromEmojis() {
    const passwordInput = document.getElementById('decryptPassword');
    const emojiInput = document.getElementById('pasteEmojis').value;
    const result = document.getElementById('decryptedText');

    const password = passwordInput.value.trim();

    if (!password) {
        alert('الرجاء إدخال كلمة المرور!');
        return;
    }
    if (!emojiInput || emojiInput.trim() === '') {
        result.textContent = 'الرجاء لصق الرموز التعبيرية!';
        return;
    }

    try {
        let base64Str = '';


        const ignoredChars = [
            ' ', '\n', '\t', '\r',
            '\u200c', '\u200d', '\u200e', '\u200f',
            '\u202a', '\u202b',
            '\uFE0F',
            '\uFE0E'
        ];

        for (let emoji of Array.from(emojiInput)) {
            if (ignoredChars.includes(emoji)) {
                continue;
            }

            const char = emojiToChar[emoji];
            if (!char) {
                result.textContent = `❌ رمز غير معروف: ${JSON.stringify(emoji)}`;
                return;
            }
            base64Str += char;
        }

        base64Str = base64Str.replace(/[^A-Za-z0-9+/=]/g, '');
        if (base64Str.length === 0) {
            result.textContent = '❌ لا توجد أحرف صالحة!';
            return;
        }


        const binaryStr = atob(base64Str);
        const combined = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i++) {
            combined[i] = binaryStr.charCodeAt(i);
        }

        const iv = combined.slice(0, 12);
        const data = combined.slice(12);

        const key = await generateKey(password);
        const decrypted = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: iv },
            key,
            data
        );

        const decoder = new TextDecoder("utf-8");
        const originalText = decoder.decode(decrypted);

        result.textContent = 'النص المسترجع: ' + originalText;

    } catch (e) {
        console.error(e);
        result.textContent = '❌ فشل فك التشفير — كلمة مرور خاطئة أو بيانات تالفة';
    }
}


function resetAllr() {
    document.getElementById('message').value = '';
    document.getElementById('emojiOutput').value = '';
    document.getElementById('encryptedImage').innerHTML = '<p style="color: #888;">يظهر الصورة المشفرة هنا</p>';
    document.getElementById('userPassword').value = '';
}


function resetAllg() {
    document.getElementById('pasteEmojis').value = '';
    document.getElementById('decryptedText').textContent = 'يتم عرض النص المسترجع هنا';
    document.getElementById('decryptPassword').value = '';
}

$(document).ready(function () {
    $("#flip").click(function () {
        $("#panel").slideDown("slow");
    });
    $("#panel").click(function () {
        $("#panel").slideUp("slow");
    });
});

$(document).ready(function () {
    $("#flip2").click(function () {
        $("#panel2").slideDown("slow");
    });
    $("#panel2").click(function () {
        $("#panel2").slideUp("slow");
    });
});