
const charToEmoji = {

    'A': '🍎', 'B': '🍌', 'C': '🍒', 'D': '🍇', 'E': '🍊',
    'F': '🍋', 'G': '🍉', 'H': '🍓', 'I': '🍑', 'J': '🍍',
    'K': '🥥', 'L': '🥝', 'M': '🍅', 'N': '🍆', 'O': '🥑',
    'P': '🥦', 'Q': '🥕', 'R': '🌽', 'S': '🌶', 'T': '🥒',
    'U': '🥬', 'V': '🥭', 'W': '🍐', 'X': '🧶', 'Y': '🌙', 'Z': '🥔',


    'a': '🍏', 'b': '🪴', 'c': '🌼', 'd': '🌻', 'e': '🪻',
    'f': '🌴', 'g': '🌱', 'h': '🌿', 'i': '☘️', 'j': '🍀',
    'k': '🍁', 'l': '🍂', 'm': '🍃', 'n': '🪨', 'o': '🐚',
    'p': '🪵', 'q': '🌾', 'r': '🌵', 's': '🌷', 't': '🌹',
    'u': '🥀', 'v': '🌺', 'w': '🌎', 'x': '🌍', 'y': '🌏', 'z': '🌐',

    // اعداد
    '0': '⚽', '1': '🥇', '2': '🥈', '3': '🥉', '4': '🎲',
    '5': '🎯', '6': '🏀', '7': '🏈', '8': '🚗', '9': '🚀',

    '+': '➕', '/': '➖', '=': '🟰', ' ': '⬜'
};

const emojiToChar = {};
for (let [char, emoji] of Object.entries(charToEmoji)) {
    emojiToChar[emoji] = char;
}

async function generateKey(password) {
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );

    return await crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: encoder.encode("salt-salt-salt-unique"),
            iterations: 100000,
            hash: "SHA-256"
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
    );
}

async function ramznegar() {
    const input = document.getElementById('message');
    const passwordInput = document.getElementById('userPassword');
    const text = input.value.trim();
    const password = passwordInput.value.trim();

    const container = document.getElementById('encryptedImage');
    const emojiOutput = document.getElementById('emojiOutput');

    if (!text) {
        alert('Please enter a text!');
        return;
    }
    if (!password) {
        alert('Please enter a password!');
        return;
    }

    try {
        const key = await generateKey(password);
        const encoder = new TextEncoder();
        const data = encoder.encode(text);

        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv: iv },
            key,
            data
        );

        const encryptedArray = new Uint8Array(encrypted);
        const combined = new Uint8Array(iv.length + encryptedArray.length);
        combined.set(iv);
        combined.set(encryptedArray, iv.length);

        const base64Data = btoa(String.fromCharCode(...combined));


        container.innerHTML = '';
        let emojiString = '';

        for (let char of base64Data) {
            const emoji = charToEmoji[char] || '❓';
            emojiString += emoji;

            const div = document.createElement('div');
            div.className = 'emoji-block';
            div.textContent = emoji;
            div.style.cssText = `
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 30px;
        height: 30px;
        margin: 2px;
        font-size: 20px;
        border-radius: 8px;
        background: ${getStyleForChar(char).match(/background:([^;]+)/)?.[1] || '#ccc'};
        color: white;
        text-shadow: 0 0 2px black;
    `;
            container.appendChild(div);
        }

        emojiOutput.value = emojiString;

    } catch (e) {
        console.error(e);
        alert('Error in encryption: ' + e.message);
    }
}

function getStyleForChar(char) {
    if (/[A-E]/.test(char)) {
        return 'width:30px;height:30px;background:#ff4444;';
    } else if (/[F-J]/.test(char)) {
        return 'width:30px;height:30px;background:#4488ff;border-radius:50%;';
    } else if (/[K-O]/.test(char)) {
        return 'width:0;height:0;border-left:15px solid transparent;border-right:15px solid transparent;border-bottom:30px solid #44ff44;';
    } else if (/[P-T]/.test(char)) {
        return 'width:22px;height:22px;background:#ffcc00;transform:rotate(45deg);';
    } else if (/[U-Z]/.test(char)) {
        return 'width:30px;height:30px;background:#aa66cc;border:2px solid #000;';
    } else if (/[a-e]/.test(char)) {
        return 'width:30px;height:30px;background:#ff9900;opacity:0.8;';
    } else if (/[f-j]/.test(char)) {
        return 'width:30px;height:30px;background:#00ccaa;';
    } else if (/[k-o]/.test(char)) {
        return 'width:30px;height:30px;background:#cc5555;border-radius:5px;';
    } else if (/[p-t]/.test(char)) {
        return 'width:30px;height:30px;background:#55cc55;';
    } else if (/[u-z]/.test(char)) {
        return 'width:30px;height:30px;background:#5555cc;';
    } else if (/[0-4]/.test(char)) {
        return 'width:30px;height:30px;background:#ccaa00;';
    } else if (/[5-9]/.test(char)) {
        return 'width:30px;height:30px;background:#aa00aa;';
    } else if (char === '+') {
        return 'width:30px;height:30px;background:#ffffff;border:2px solid #000;';
    } else if (char === '/') {
        return 'width:30px;height:30px;background:#000000;';
    } else if (char === '=') {
        return 'width:30px;height:30px;background:#666666;';
    } else {
        return 'width:30px;height:30px;background:#cccccc;';
    }
}

function copyEmojis() {
    const output = document.getElementById('emojiOutput');
    output.select();
    document.execCommand('copy');
    alert('Emojis copied! 🎉');
}


async function ramzgoshaFromEmojis() {
    const passwordInput = document.getElementById('decryptPassword');
    const emojiInput = document.getElementById('pasteEmojis').value.trim();
    const result = document.getElementById('decryptedText');

    const password = passwordInput.value.trim();

    if (!password) {
        alert('Please enter the password!');
        return;
    }
    if (!emojiInput) {
        result.textContent = 'Please paste some emojis!';
        return;
    }

    try {
        let base64Str = '';
        for (let emoji of Array.from(emojiInput)) {
            const char = emojiToChar[emoji];
            if (!char) {
                result.textContent = '❌ Unknown emoji: ' + emoji;
                return;
            }
            base64Str += char;
        }


        const binaryStr = atob(base64Str);
        const combined = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i++) {
            combined[i] = binaryStr.charCodeAt(i);
        }

        const iv = combined.slice(0, 12);
        const data = combined.slice(12);


        const key = await generateKey(password);
        const decrypted = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: iv },
            key,
            data
        );

        const decoder = new TextDecoder("utf-8");
        const originalText = decoder.decode(decrypted);

        result.textContent = 'Recovered text: ' + originalText;

    } catch (e) {
        console.error(e);
        result.textContent = '❌ Decryption failed — Wrong password or corrupted data';
    }
}

function resetAllr() {
    document.getElementById('message').value = '';
    document.getElementById('emojiOutput').value = '';
    document.getElementById('encryptedImage').innerHTML = '<p style="color: #888;">The encrypted image is displayed here</p>';
    document.getElementById('userPassword').value = '';
}
function resetAllg() {
    document.getElementById('pasteEmojis').value = '';
    document.getElementById('decryptedText').textContent = 'Reconstructed text';
    document.getElementById('decryptPassword').value = '';
}



