
function hasPersianOrArabic(text) {
  const normalized = text.normalize("NFC");
  const regex = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF\u064B-\u065F\u0670\u06D6-\u06ED]/;
  const rtlChars = /[\u200F\u202A-\u202E\u2066-\u2069]/;
  const zwSpace = /\u200C/;
  return regex.test(normalized) || rtlChars.test(normalized) || zwSpace.test(normalized);
}

async function generateKey(password) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw", encoder.encode(password), { name: "PBKDF2" }, false, ["deriveKey"]
  );
  return await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: encoder.encode("salt-salt-salt-unique"),
      iterations: 100000,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function encrypt() {
  const input = document.getElementById("inputText").value;
  const password = document.getElementById("password").value;
  const output = document.getElementById("outputText");

  if (!input) return alert("Enter text to encrypt.");
  if (!password) return alert("Enter a password.");
  if (hasPersianOrArabic(input)) {
    alert("❌ Persian/Arabic not allowed.");
    output.value = "Blocked: Persian/Arabic detected.";
    return;
  }

  try {
    const key = await generateKey(password);
    const encoder = new TextEncoder();
    const data = encoder.encode(input);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, data);

    const encryptedArray = new Uint8Array(encrypted);
    const combined = new Uint8Array(iv.length + encryptedArray.length);
    combined.set(iv);
    combined.set(encryptedArray, iv.length);

    const base64 = btoa(String.fromCharCode(...combined));
    output.value = base64;
  } catch (e) {
    output.value = "Error: " + e.message;
  }
}

function copyOutput() {
  const output = document.getElementById("outputText");
  if (!output.value) return alert("Nothing to copy.");
  output.select();
  document.execCommand("copy");
  alert("✅ Copied to clipboard!");
}

function reset() {
  document.getElementById("inputText").value = "";
  document.getElementById("password").value = "";
  document.getElementById("outputText").value = "";
  document.getElementById("inputText").focus();
}


function cleanBase64(str) {
  return str.trim().replace(/[\u200B-\u200D\uFEFF\r\n\t\s]+/g, "");
}

async function generateKey(password) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw", encoder.encode(password), { name: "PBKDF2" }, false, ["deriveKey"]
  );
  return await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: encoder.encode("salt-salt-salt-unique"),
      iterations: 100000,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function decrypt() {
  let input = document.getElementById("inputText").value;
  const password = document.getElementById("password").value;
  const output = document.getElementById("outputText");

  if (!input) return alert("Paste encrypted text.");
  if (!password) return alert("Enter password.");

  input = cleanBase64(input);

  if (!/^[A-Za-z0-9+/=]+$/.test(input)) {
    output.value = "❌ Invalid base64 format.";
    return;
  }

  try {
    const key = await generateKey(password);
    const decoded = atob(input);
    const combined = Uint8Array.from(decoded, c => c.charCodeAt(0));

    if (combined.length < 12) throw new Error("Invalid data.");

    const iv = combined.slice(0, 12);
    const data = combined.slice(12);

    const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
    const plainText = new TextDecoder("utf-8").decode(decrypted);

    output.value = plainText;
  } catch (e) {
    output.value = "❌ Decryption failed — wrong password or corrupted data.";
  }
}

function copyOutput() {
  const output = document.getElementById("outputText");
  if (!output.value) return alert("Nothing to copy.");
  output.select();
  document.execCommand("copy");
  alert("✅ Copied!");
}

function reset() {
  document.getElementById("inputText").value = "";
  document.getElementById("password").value = "";
  document.getElementById("outputText").value = "";
  document.getElementById("inputText").focus();
}

